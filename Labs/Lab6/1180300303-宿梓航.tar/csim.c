#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <limits.h>
#include <string.h>
#include <errno.h>
#include <stdbool.h>
#include "cachelab.h"

//#define TRACE_ON
#define ADDRESS_LENGTH 64
#define BUFFER_SIZE 1<<10



/* Type: Memory address */
typedef unsigned long long ulong;
typedef unsigned char byte;
typedef char* string;

/* Type: Cache line
   Lru is a counter used to implement Lru replacement policy  */
typedef struct
{
	bool Valid;
	ulong Tag; //Memory Address
	ulong Lru; //Lru Storage
} TCacheLine;

typedef TCacheLine *TCacheSet;
typedef TCacheSet *TCache;

/* Globals set by command line args */
bool Verbosity = false;		  /* print trace if set */
int IndexBitsCount = 0;		  /* set index bits */
int BlockOffsetBitsCount = 0; /* block offset bits */
int Associativity = 0;		  /* associativity */
char *trace_file = NULL;

/* Derived from command line args */
int SetsCount; /* number of sets */
int BlockSize; /* block size (bytes) */

/* Counters used to record Cache statistics */
int MissCount = 0;
int HitCount = 0;
int EvictionCount = 0;
ulong GlobalLRU = 1;

/* The Cache we are simulating */
TCache Cache;
ulong SetIndexMask;

/* 
 * InitCache - Allocate memory, write 0'IndexBitsCount for Valid and Tag and Lru
 * also computes the SetIndexMask
 */
void InitCache()
{
	Cache = malloc(SetsCount << 3);
	for (int i = 0; i < SetsCount;
		 Cache[i++] = calloc(Associativity, sizeof(TCacheLine)))
		;
	SetIndexMask = SetsCount - 1;
}

/* 
 * FreeCache - free allocated memory
 */
void FreeCache()
{
	for (int i = 0; i < SetsCount;
		 free(Cache[i++]))
		;
	free(Cache);
}

/* 
 * AccessData - Access data at memory address address.
 *   If it is already in Cache, increast HitCount
 *   If it is not in Cache, bring it in Cache, increase miss count.
 *   Also increase EvictionCount if a line is evicted.
 */
void AccessData(ulong address)
{
	ulong tag = address >> ((IndexBitsCount + BlockOffsetBitsCount) & 0xFF);
	TCacheSet cacheSet = Cache[(address >> BlockOffsetBitsCount) & SetIndexMask];

	//Search for tag
	for (int i = 0; i < Associativity; i++)
	{
		if (cacheSet[i].Valid && cacheSet[i].Tag == tag)//ChacheHit
		{
			HitCount++;
			if (Verbosity)
				printf("hit ");
			cacheSet[i].Lru = GlobalLRU++;//Update LRU
			return;
		}
	}
	//tag not found
	MissCount++;
	if (Verbosity)
		printf("miss ");
	//find location to evict, with LRU
	//because if !cacheSet[i].Valid, cacheSet[i].Lru=0 < cacheSet.Any(x=>x.Valid).Lru'
	//	if (!cacheSet[i].Valid)
	//	{
	//		minPtr = i;break;
	//	}
	//	'is not necessary
	int minPtr = 0;
	for (int i = 0; i < Associativity; i++)
		if (cacheSet[i].Lru < cacheSet[minPtr].Lru)
			minPtr = i;
	if (cacheSet[minPtr].Valid)
	{
		EvictionCount++;
		if (Verbosity)
			printf("eviction ");
	}
	//Update Block info
	cacheSet[minPtr].Valid = true;
	cacheSet[minPtr].Tag = tag;
	//Update Lru
	cacheSet[minPtr].Lru = GlobalLRU++;
	return;
}

/*
 * ReplayTrace - replays the given trace file against the Cache 
 */
void ReplayTrace(string traceFileName)
{
	int length;
	ulong address;
	static char buffer[BUFFER_SIZE];
	FILE* traceFile = fopen(traceFileName, "r");

	//File not found || unable to open
	if (!traceFile)
	{
		fprintf(stderr, "%s: %s\n", traceFileName, strerror(*__errno_location()));
		exit(1);
	}

	while (fgets(buffer, BUFFER_SIZE, traceFile))
	{
		if (buffer[1] == 'S' || buffer[1] == 'L' || buffer[1] == 'M')
		{
			sscanf(buffer + 3, "%llx,%u", &address, &length);
			if (Verbosity)
				printf("%c %llx,%u ", buffer[1], address, length);
			AccessData(address);
			if (buffer[1] == 'M')
				AccessData(address);
			if (Verbosity)
				putchar('\n');
		}
	}

	fclose(traceFile);
}

/*
 * printUsage - Print usage info
 */
void printUsage(string argv[])
{
	printf("Usage: %s [-hv] -s <num> -E <num> -b <num> -t <file>\n", argv[0]);
	printf("Options:\n");
	printf("  -h         Print this help message.\n");
	printf("  -v         Optional verbose flag.\n");
	printf("  -s <num>   Number of set index bits.\n");
	printf("  -E <num>   Number of lines per set.\n");
	printf("  -b <num>   Number of block offset bits.\n");
	printf("  -t <file>  Trace file.\n");
	printf("\nExamples:\n");
	printf("  linux>  %s -s 4 -E 1 -b 4 -t traces/yi.trace\n", argv[0]);
	printf("  linux>  %s -v -s 8 -E 2 -b 4 -t traces/yi.trace\n", argv[0]);
	exit(0);
}

/*
 * main - Main routine 
 */
int main(int argc, string argv[])
{
	char c;

	while ((c = getopt(argc, argv, "s:E:b:t:vh")) != -1)
	{
		switch (c)
		{
		case 's':
			IndexBitsCount = atoi(optarg);
			break;
		case 'E':
			Associativity = atoi(optarg);
			break;
		case 'b':
			BlockOffsetBitsCount = atoi(optarg);
			break;
		case 't':
			trace_file = optarg;
			break;
		case 'v':
			Verbosity = true;
			break;
		case 'h':
			printUsage(argv);
			exit(0);
		default:
			printUsage(argv);
			exit(1);
		}
	}

	/* Make sure that all required command line args were specified */
	if (!IndexBitsCount || !Associativity || !BlockOffsetBitsCount || !trace_file)
	{
		printf("%s: Missing required command line argument\n", argv[0]);
		printUsage(argv);
		exit(1);
	}

	/* Compute SetsCount, Associativity and BlockSize from command line args */

	//Associativity=
	SetsCount = 1 << IndexBitsCount;
	BlockSize = 1 << BlockOffsetBitsCount;
	/* Initialize Cache */
	InitCache();

#ifdef TRACE_ON
	printf("DEBUG: SetsCount:%u Associativity:%u BlockSize:%u trace:%IndexBitsCount\n", SetsCount, Associativity, BlockSize, trace_file);
	printf("DEBUG: SetIndexMask: %llu\n", SetIndexMask);
#endif

	ReplayTrace(trace_file);

	/* Free allocated memory */
	FreeCache();

	/* Output the hit and miss statistics for the autograder */
	printSummary(HitCount, MissCount, EvictionCount);
	return 0;
}
